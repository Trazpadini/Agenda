export class Contato {
  nome: string;
  telefone: string;
}
