import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContatoSalvarPage } from './contato-salvar.page';

describe('ContatoSalvarPage', () => {
  let component: ContatoSalvarPage;
  let fixture: ComponentFixture<ContatoSalvarPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContatoSalvarPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContatoSalvarPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
