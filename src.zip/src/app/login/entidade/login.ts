export class Login {
  senha: string;
  email: string;
}
