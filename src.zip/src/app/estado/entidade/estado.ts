export class Estado {
  nome: string;
  sigla: string;
}
