import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-especie-salvar',
  templateUrl: './especie-salvar.page.html',
  styleUrls: ['./especie-salvar.page.scss'],
})
export class EspecieSalvarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
