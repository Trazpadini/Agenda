import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-especie-listar',
  templateUrl: './especie-listar.page.html',
  styleUrls: ['./especie-listar.page.scss'],
})
export class EspecieListarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
