export class Especie {
  nome: string;
}
