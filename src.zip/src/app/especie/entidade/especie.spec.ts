import { Especie } from './especie';

describe('Especie', () => {
  it('should create an instance', () => {
    expect(new Especie()).toBeTruthy();
  });
});
