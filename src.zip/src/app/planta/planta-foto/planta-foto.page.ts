import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planta-foto',
  templateUrl: './planta-foto.page.html',
  styleUrls: ['./planta-foto.page.scss'],
})
export class PlantaFotoPage implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
