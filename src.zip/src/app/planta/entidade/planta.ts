export class Planta {
    cientifico: string;
    popular: string;
    idade: number;
}
