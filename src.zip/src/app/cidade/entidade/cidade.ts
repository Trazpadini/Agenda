import { Estado } from 'src/app/estado/entidade/estado';

export class Cidade {
  nome: string;
  estado:Estado;
}
