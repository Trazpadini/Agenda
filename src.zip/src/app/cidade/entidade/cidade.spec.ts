import { Cidade } from './cidade';

describe('Cidade', () => {
  it('should create an instance', () => {
    expect(new Cidade()).toBeTruthy();
  });
});
